const os = require('os');
const WebSocket = require('ws');
const uuid = require('uuid');
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function getLocalIPv4() {
  const interfaces = os.networkInterfaces();
  for (const iface of Object.values(interfaces)) {
    for (const info of iface) {
      if (info.family === 'IPv4' && !info.internal) {
        return info.address;
      }
    }
  }
  return '127.0.0.1';
}

rl.question('Enter bot token: ', (telegramToken) => {
  rl.question('Enter chat ID: ', (chatId) => {
    rl.close();

    const config = { telegramToken, chatId };
    if (!fs.existsSync('config.json')) {
      fs.writeFileSync('config.json', JSON.stringify(config, null, 2));
    }

    const owner = 'minecraftwiki55';
    if (!fs.existsSync('admin.json')) {
      const admin = { admins: [owner] };
      fs.writeFileSync('admin.json', JSON.stringify(admin, null, 2));
    }

    const bot = new TelegramBot(telegramToken, { polling: true });

    const localIP = getLocalIPv4();
    console.log(`Ready. On Minecraft chat, type /connect ${localIP}:3000`);
    
    const wss = new WebSocket.Server({ port: 3000 });

    wss.on('connection', socket => {
      console.log('Connected');

      socket.send(JSON.stringify({
        "header": {
          "version": 1,
          "requestId": uuid.v4(),
          "messageType": "commandRequest",
          "messagePurpose": "subscribe"
        },
        "body": {
          "eventName": "PlayerMessage"
        },
      }));

      const sendCommandToMinecraft = (command) => {
        const msg = {
          "header": {
            "version": 1,
            "requestId": uuid.v4(),
            "messagePurpose": "commandRequest",
            "messageType": "commandRequest"
          },
          "body": {
            "version": 1,
            "commandLine": command,
            "origin": {
              "type": "player"
            }
          }
        }
        socket.send(JSON.stringify(msg))
      }

      socket.on('message', packet => {
        const msg = JSON.parse(packet);

        if (msg.body && msg.body.message && msg.body.sender) {
          const formattedMessage = `<${msg.body.sender}> ${msg.body.message}`;
          console.log(formattedMessage);
          bot.sendMessage(chatId, formattedMessage);
        }
      });

      bot.onText(/^\/cmd (.+)/, (msg, match) => {
        const chatId = msg.chat.id;
        const userId = msg.from.username;
        const command = match[1];

        const adminData = JSON.parse(fs.readFileSync('admin.json', 'utf-8'));
        if (!adminData.admins.includes(userId)) {
          return bot.sendMessage(chatId, '⚠️ You are not an admin!');
        }

        if (command) {
          console.log(`Executing Minecraft command: ${command}`);
          wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
              sendCommandToMinecraft(command);
            }
          });
          bot.sendMessage(chatId, `✅ Command sent to Minecraft: \`${command}\``, { parse_mode: 'Markdown' });
        } else {
          bot.sendMessage(chatId, '⚠️ Usage: /cmd [command]');
        }
      });
    });
  });
});
